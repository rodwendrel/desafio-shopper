import { Route } from "../types/route";
import { Ride } from "./ride";

export const routes: Route[] = [...Ride];